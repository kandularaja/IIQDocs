package com.example.integration;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.List;
import java.util.Map;

import sailpoint.api.SailPointContext;
import sailpoint.integration.AbstractIntegrationExecutor;
import sailpoint.integration.ProvisioningPlan;
import sailpoint.integration.ProvisioningPlan.AccountRequest;
import sailpoint.integration.ProvisioningPlan.AttributeRequest;
import sailpoint.integration.RequestResult;
import sailpoint.object.Attributes;
import sailpoint.object.IntegrationConfig;

public class DemoIntegrationConfig extends AbstractIntegrationExecutor {

	private Attributes configAttrs = new Attributes();
	private SailPointContext context = null;
	
	@Override
	public void configure(SailPointContext context, IntegrationConfig config)
			throws Exception {
		// TODO Auto-generated method stub
		this.configAttrs = config.getAttributes();
		this.context = context;
		super.configure(context, config);
	}

	@Override
	public RequestResult provision(String identity,
			sailpoint.integration.ProvisioningPlan plan) throws Exception {
		// TODO Auto-generated method stub
		
		System.out.println("Plan from provision() method:"+plan.toMap());
		Map<String,Object> args = plan.getArguments();	
		List<AccountRequest> acctReqs = plan.getAccountRequests();
		RequestResult result = new RequestResult();
		
		if(acctReqs != null)
		{
			AccountRequest acctReq = acctReqs.get(0);
			List<AttributeRequest> attributes = acctReq.getAttributeRequests();
			for(int i=0;i<attributes.size();i++)
			{
				AttributeRequest attrReq = attributes.get(i);
				args.put(attrReq.getName(), attrReq.getValue());
			}
			String operation = acctReq.getOperation();
			if(operation != null && operation.equals(ProvisioningPlan.OP_ACCOUNT_CREATE))
			{
				String ticketId = createTicket(args);
				result.setStatus(RequestResult.STATUS_SUCCESS);
				result.setRequestID(ticketId);
			}
		}
		
		return result;
		//return super.provision(identity, plan);
	}
	
	private Connection getTicketDBConnection() throws Exception
	{
		String driverName = (String)configAttrs.getString("driver");
		String dbHost = (String)configAttrs.getString("databaseHost");
		String dbPort = (String)configAttrs.getString("databasePort");
		String dbName = (String)configAttrs.getString("databaseName");
		String username = (String)configAttrs.getString("username");
		String password = (String)configAttrs.getString("password");
		
		Class.forName(driverName);
		String jdbcUrl = "jdbc:mysql://"+dbHost+":"+dbPort+"/"+dbName+"?user="+username+"&password="+password;
		Connection conn = DriverManager.getConnection(jdbcUrl);
		return conn;
	}
	
	public String createTicket(Map ticketData) throws Exception
	{
		Connection con = getTicketDBConnection();
		String tableName = (String)configAttrs.getString("tableName");
		String ticketId = getNewTicketId(con);
		String insertStmt = "insert into "+tableName+" values(?,?,?,?,?,?,?,?,?,?,?)";
		PreparedStatement ps = con.prepareStatement(insertStmt);
		ps.setString(1, ticketId);
		ps.setString(2, (String)ticketData.get("category"));
		ps.setString(3, (String)ticketData.get("type"));
		ps.setString(4, (String)ticketData.get("item"));
		ps.setString(5, (String)ticketData.get("description"));
		ps.setString(6, (String)ticketData.get("createDate"));
		ps.setString(7, (String)ticketData.get("lastModified"));
		ps.setString(8, (String)ticketData.get("requestedByUserId"));
		ps.setString(9, (String)ticketData.get("requestedByUserFullName"));
		ps.setString(10, (String)ticketData.get("requesteeUserId"));
		ps.setString(11, (String)ticketData.get("requesteeUserFullName"));
		
		int insStatus = ps.executeUpdate();
		System.out.println("Insert Status:"+insStatus);
		
		closeTicketDBConnection(con);
		
		if(insStatus == 1)
			return ticketId;
		else
			return "00000";
	}
	
	private String getNewTicketId(Connection con) throws Exception
	{
		String newTicketId = null;
		int nextId = 0;
		String sql = "select NEXTVAL from user_tickets_seq";
		Statement stmt = con.createStatement();
		ResultSet rs = stmt.executeQuery(sql);
		if(rs != null && rs.next())
		{
			newTicketId = rs.getString(1);
			nextId = Integer.parseInt(newTicketId)+1;
			newTicketId = String.format("%06d",Integer.parseInt(newTicketId));
		}
		
		rs.close();
		String updateSql = "update ticketsys.user_tickets_seq set NEXTVAL='"+nextId+"'";
		stmt = con.createStatement();
		stmt.executeUpdate(updateSql);
		System.out.println("New Ticket Id:"+"REQ"+newTicketId);
		return "REQ"+newTicketId;
	}
	
	private void closeTicketDBConnection(Connection con) throws Exception
	{
		con.close();
	}

}
