package com.example.integration;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.util.List;

import sailpoint.api.SailPointContext;
import sailpoint.connector.Connector;
import sailpoint.integration.AbstractIntegrationExecutor;
import sailpoint.object.Application;
import sailpoint.object.IntegrationConfig;
import sailpoint.object.ProvisioningPlan;
import sailpoint.object.ProvisioningPlan.AccountRequest;
import sailpoint.object.ProvisioningResult;
import sailpoint.object.Schema;


public class ProvisionIntegrationModule extends AbstractIntegrationExecutor
{
	private SailPointContext context;
	@Override
	public void configure(SailPointContext context, IntegrationConfig config)
			throws Exception {
		// TODO Auto-generated method stub
		this.context  = context;
		super.configure(context, config);
	}

	@Override
	public ProvisioningResult provision(ProvisioningPlan plan) throws Exception 
	{
		// TODO Auto-generated method stub
		System.out.println("Plan in integration config:"+plan.toXml());
		List<AccountRequest> accReqs = plan.getAccountRequests();
		for(int i=0;i<accReqs.size();i++)
		{
			AccountRequest accReq = accReqs.get(i);
			String applicationName =  accReq.getApplicationName();
			ProvisioningPlan.AccountRequest.Operation operation = accReq.getOperation();
			System.out.println("App Name:"+applicationName);
			Application app = this.context.getObjectByName(Application.class,applicationName);
			String filePath = (String)app.getAttributeValue("file");
			if(operation != null && operation.equals(ProvisioningPlan.AccountRequest.Operation.Create))
			{
				Schema sch = app.getSchema(Connector.TYPE_ACCOUNT);
				List<String> appAttrs = sch.getAttributeNames();
				StringBuffer lineItem =  new StringBuffer();
				for(int j=0;j<appAttrs.size();j++)
				{
					lineItem.append((String)(accReq.getAttributeRequest(appAttrs.get(j)).getValue()));
					lineItem.append(",");
				}
				String line = lineItem.substring(0, lineItem.length()-1);
				System.out.println("Line Item:"+line);
				writeLine(filePath,line);
			}
		}
		ProvisioningResult pr = new ProvisioningResult();
		pr.setStatus(ProvisioningResult.STATUS_COMMITTED);
		return pr;
		//return super.provision(plan);
	}
	
	private void writeLine(String filepath,String line) throws Exception
	{
		File file = new File(filepath);
		FileWriter fw =  new FileWriter(file,true);
		BufferedWriter bw = new BufferedWriter(fw);
		bw.newLine();
		bw.write(line);
		bw.close();
		fw.close();
		System.out.println("Line has been written successfully!!");
	}
	
}
