/* Copyright (C) CodeIQ - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential
 * Written by Pawan Kumar <pawan.kumar@sdgc.com>, Feb 2017
 */
/*---------------------------------------Ajax Filter---------------------------------------------------*/
jQuery.ajaxPrefilter(function(options, originalOptions, jqXHR) {

    jqXHR.setRequestHeader('X-XSRF-TOKEN', PluginHelper.getCsrfToken());
});

/*---------------------------------------ENDS---------------------------------------------------*/


/*---------------------------------------Editor intiter variables---------------------------------------------------*/
var appName = SailPoint.CONTEXT_PATH;
errors = [];
editor = null;
var ruleType = null;
var returnType = null;
var arguments = [];
var hasError = false;
var containerX = null;
var count = 0;
var data;
var glbText;
var GUTTER_ID = "CodeMirror-lint-markers";

function invokeEditorObj() {


    console.log("THIS IS Beta version of CODEIQ");
    editor = CodeMirror.fromTextArea(document.getElementById("source-inputEl"), {
        lineNumbers: true,
        extraKeys: {
            "Ctrl-Space": "autocomplete"
        },
        matchBrackets: true,
        ctrl_bracket: "highlight-brackets",
        ctrl_shift_bracket: "jump-to-matching-bracket",
        foldGutter: true,
        //mode:"text/x-java",
        mode: "javascript",
        gutters: ["CodeMirror-lint-markers"],
        lint: true
    });

    editor.on("change", function(editor) {
        var val = editor.getValue();
        //if (val !== '')
        {

            firstValidateCodeAdvance(val);


        }

    });
    ruleType = jQuery('#ruleType-body').text();
    returnType = jQuery('#rtnType-body').text();
    /*---------------------------------------Hints initater---------------------------------------------------*/



    CodeMirror.hint.javascript = function(editor) {

        console.clear();
        glAssist = [];
        var hnt = [];
        var cursor = editor.getCursor();

        var currentLine = editor.getLine(cursor.line);

        var start = cursor.ch;
        var end = start;
        while (end < currentLine.length && /[\w$]+/.test(currentLine.charAt(end)))
            ++end;
        while (start && /[\w$]+/.test(currentLine.charAt(start - 1)))
            --start;
        var curWord = start != end && currentLine.slice(start, end);


        var fdf = ["pawan", "hello"];
        var regex = new RegExp('^' + curWord, 'i');

        var suggester = [];
        var currentLineArr = currentLine.split(" ");

        if (currentLineArr != null && currentLineArr[currentLineArr.length - 1].indexOf("context.") != -1) {
            if (curWord.length != 0 || curWord != false) {
                suggester = context.filter(function(item) {
                    return item.match(regex);
                });
            }
            if (curWord.length == 0 || curWord == false) {
                suggester = context;
            }

        } else if (currentLineArr != null && currentLineArr[currentLineArr.length - 1].indexOf("log.") != -1) {

            if (curWord.length != 0 || curWord != false) {
                suggester = log.filter(function(item) {
                    return item.match(regex);
                });
            }
            if (curWord.length == 0 || curWord == false) {
                suggester = log;
            }

        } else if (currentLineArr != null && currentLineArr[currentLineArr.length - 1].indexOf("System.") != -1) {

            if (curWord.length != 0 || curWord != false) {
                suggester = system.filter(function(item) {
                    return item.match(regex);
                });
            }
            if (curWord.length == 0 || curWord == false) {
                suggester = system;
            }

        } else {


            var tokenWord = currentLine;
            if (tokenWord.lastIndexOf(".") != -1) {

                tokenWord = tokenWord.substring(0, tokenWord.lastIndexOf("."))
            }
            suggester = [];
            codeAssist(editor.getValue(), tokenWord, ruleType);

            if (glAssist.length != 0) {


                if (curWord.length != 0 || curWord != false) {
                    suggester = glAssist.filter(function(item) {
                        return item.match(regex);
                    });
                }
                if (curWord.length == 0 || curWord == false) {
                    suggester = glAssist;
                }

                glAssist = [];

            }

        }

        var result = { //If curWord is true then call filter annomnous function otherwise 

            list: suggester.sort(),
            from: CodeMirror.Pos(cursor.line, start),
            to: CodeMirror.Pos(cursor.line, end)
        };
        suggester = [];
        return result;
    };


}




/*---------------------------------------Editor Eventers---------------------------------------------------*/


function createEditor() {

    if (editor != null) {
        retainState();
        invokeEditorObj();
    } else {
        invokeEditorObj();
    }
    count++;
}

jQuery(document).on('click', '.ruleEditorBtn', function() {

    var myVar = setTimeout(createEditor, 500);
});

//When cancel button called
jQuery(document).on('click', '#ruleCancel-btnInnerEl', function() {
    retainState();
    count = 0;
});
//When save button called
jQuery(document).on('click', '#ruleSave-btnEl', function() {



    editor.save();

});

jQuery(document).on('click', '#ruleSave-btnInnerEl', function() {



    //Dummy method for future use


});

//Method for reset changes
function retainState() {
    textarea = document.getElementById("source-inputEl");

    textarea.parentNode.removeChild(editor.getWrapperElement());
    textarea.style.display = "";
    editor = null;

    if (textarea.form) {
        off(textarea.form, "submit", save);
        if (typeof textarea.form.submit == "function")
            textarea.form.submit = realSubmit;
    }

}




jQuery(document).on('focus', '#source-inputEl', function() {

    //Dummy method for focus ::Future release
    //Events on editor
    var i = 0;
    editor.on("renderLine", function() {


        i++;
    });
});




/*---------------------------------------editor intiter ends---------------------------------------------------*/
var widgets = [];


//---------Code with Advance sideline gutters output--------------
function firstValidateCodeAdvance(val) {

    var PAGE_CONFIG_URL = PluginHelper.getPluginRestUrl('sailcode/compile');


    jQuery.ajax({
        url: PAGE_CONFIG_URL,
        type: "GET",
        data: {
            "appName": appName,
            'source': val,
            'ruleType': ruleType,
            'returnType': returnType
        },
        success: function(response) {



            if (response != null) {

                if (response.indexOf("TYPE:OK") != -1) {
                    hasError = false;
                    //clearMarks(editor);
                    jQuery('#ruleErrorMsg').show();
                    jQuery('#ruleErrorMsg').css("color", "green");
                    jQuery('#ruleErrorMsg').html("<b>Your code is Fine!!!<b>");
                    errors = [];
                    clearMarks(editor, errors);

                }
                if (response.indexOf("TYPE:ERROR") != -1) {
                    errors = [];
                    hasError = true;
                    jQuery('#ruleErrorMsg').show();
                    jQuery('#ruleErrorMsg').css("color", "red");
                    jQuery('#ruleErrorMsg').html("<b>Your code has errors</b>");

                    var resultOp = response.replace("TYPE:ERROR#", "");
                    var resultArg = resultOp.split("[NEXT]");
                    for (var counter = 0; counter < resultArg.length; counter++) {

                        var lineNum = 1;
                        var errMsg = "Default issue";
                        var errorMap = resultArg[counter];
                        if (errorMap.indexOf("[#]") != -1) {
                            var errorMapArr = errorMap.split("[#]");

                            lineNum = parseInt(errorMapArr[0]);
                            errMsg = errorMapArr[1];


                            errors.push({
                                id: "(error)",
                                errMessage: errMsg,
                                evidence: " ",
                                line: lineNum,
                                character: 1
                            });
                        }


                    }
                    clearMarks(editor, errors);




                }

                editor.operation(function() {

                    for (var i = 0; i < errors.length; ++i) {

                        var err = errors[i];
                        if (!err)
                            continue;

                        editor.setGutterMarker(err.line - 1, "CodeMirror-lint-markers", makeMarker1(err.errMessage));

                    }


                });


            }


        },
        error: function(xhr, textStatus, thrownError) {
            console.log("xhr status: " + xhr.statusText);
        },
    });
}



function makeMarker1(errMessage) {
    //("makemarker called");
    var tip = document.createElement("div");
    tip.className = "CodeMirror-lint-message-error";
    tip.appendChild(document.createTextNode(errMessage));

    var labels = tip;
    var severity = "error";
    var multiple = false;
    var tooltips = true;
    var marker = document.createElement("div"),
        inner = marker;
    marker.className = "CodeMirror-lint-marker-" + severity;
    if (multiple) {
        inner = marker.appendChild(document.createElement("div"));
        inner.className = "CodeMirror-lint-marker-multiple";
    }

    if (true)
        CodeMirror.on(inner, "mouseover", function(e) {

            showTooltipFor(e, labels, inner);
        });

    return marker;
}


function showTooltipFor(e, content, node) {

    var tooltip = showTooltip(e, content);

    function hide() {
        CodeMirror.off(node, "mouseout", hide);
        if (tooltip) {
            hideTooltip(tooltip);
            tooltip = null;
        }
    }
    var poll = setInterval(function() {
        if (tooltip)
            for (var n = node;; n = n.parentNode) {
                if (n == document.body)
                    return;
                if (!n) {
                    hide();
                    break;
                }
            }
        if (!tooltip)
            return clearInterval(poll);
    }, 400);
    CodeMirror.on(node, "mouseout", hide);
}

function hideTooltip(tt) {
    //("hidetooltip called");
    if (!tt.parentNode)
        return;
    if (tt.style.opacity == null)
        rm(tt);
    tt.style.opacity = 0;
    setTimeout(function() {
        rm(tt);
    }, 600);
}

function showTooltip(e, content) {
    //("showtooltip called");
    var tt = document.createElement("div");
    tt.className = "CodeMirror-lint-tooltip";
    tt.appendChild(content.cloneNode(true));
    //tt.appendChild(content);
    document.body.appendChild(tt);

    function position(e) {
        //("position called");
        if (!tt.parentNode)
            return CodeMirror.off(document, "mousemove", position);
        tt.style.top = Math.max(0, e.clientY - tt.offsetHeight - 5) + "px";
        tt.style.left = (e.clientX + 5) + "px";
    }
    CodeMirror.on(document, "mousemove", position);
    position(e);
    if (tt.style.opacity != null)
        tt.style.opacity = 1;
    return tt;
}

function rm(elt) {
    //("rm called");
    if (elt.parentNode)
        elt.parentNode.removeChild(elt);
}

function clearMarks(cm, errx) {


    if (typeof(editor) !== 'undefined' && editor != null) {


        cm = editor;
        var state = cm.state.lint;
        if (state.hasGutter)
            cm.clearGutter(GUTTER_ID, errx);
        for (var i = 0; i < state.marked.length; ++i) {

            state.marked[i].clear();
        }

        state.marked.length = 0;
    }
}


var glAssist = [];

function codeAssist(src, keyword, ruleType) {
    var methodBlockArray = [];

    var PAGE_CONFIG_URL = PluginHelper.getPluginRestUrl('sailcode/codeAssist');

    jQuery.ajax({
        url: PAGE_CONFIG_URL,
        type: "GET",
        dataType: 'json',
        async: false,
        data: {
            "keyword": keyword,
            "source": src,
            "ruleType": ruleType
        },
        success: function(response) {


            var assitanceData = response;
            Object.keys(assitanceData).forEach(function(key) {
                var methodArr = assitanceData[key];
                if (methodArr.indexOf("NOT FOUND") == -1) {
                    if (methodArr.indexOf(";") != -1) {
                        var mArr = methodArr.split(";");
                        for (var i = 0; i < mArr.length; i++) {
                            if (mArr[i].indexOf("#") != -1) {

                                methodBlockArray.push(mArr[i].split("#")[0]);
                            }

                        }

                    }

                }

            });

            glAssist = [];
            glAssist = methodBlockArray;

        },
        error: function(xhr, textStatus, thrownError) {
            methodBlockArray = ['NOT FOUND'];
            glAssist = methodBlockArray;
            console.log("xhr status: " + xhr.statusText);
        },
    });

}